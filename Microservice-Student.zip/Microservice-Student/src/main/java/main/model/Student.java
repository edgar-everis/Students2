package main.model;

import java.time.LocalDate;



import javax.validation.constraints.Size;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonFormat;


@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@Document(collection = "Student")
public class Student {
   
	@Id
    private String id;
    
	@Size(min=3,  message= "el nombre debe tener minimo 3 letras")
    private String fullname;
	
	@Size(min=1,  message= "el genero debe tener minimo 1 letra")
    private String gender;
    
    @JsonFormat(pattern = "yyyy-MM-dd", shape = JsonFormat.Shape.STRING)
    private LocalDate birthday;
    
    @Size(min=3,  message= "el tipo de documento debe tener minimo 3 letras")
    private String typedoc;
   
    @Size(min=6,  message= "el documento debe tener minimo 6 letras")
    private String document;
}
