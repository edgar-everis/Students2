package main.expose;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import org.assertj.core.api.Assertions;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.reactive.server.WebTestClient;

import main.model.Student;
import main.service.StudentService;
import reactor.core.publisher.Mono;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class StudentControllerTest {

@Autowired
private WebTestClient client;
@Autowired
private StudentService service;	

	
	@Test
	public void testGetall() {
	client.get().uri("/API/Student").accept(MediaType.APPLICATION_JSON_UTF8).exchange()
    .expectStatus().isOk().expectHeader().contentType(MediaType.APPLICATION_JSON_UTF8).expectBodyList(Student.class)
    .consumeWith(response -> {
    final List<Student>  students = response.getResponseBody();
    students.forEach(p -> {
    	 System.out.println(p.getFullname());
            });

            Assertions.assertThat(students.size()>0).isTrue();
		  });
	}

	@Test
	public void testFindbyFullname() {
		 Student stu = service.findByFullname("Edgar").block();
	        client.get()
	                .uri("/API/Student" + "/fullname/{fullname}", Collections.singletonMap("fullname", stu.getFullname()))
	                .accept(MediaType.APPLICATION_JSON_UTF8)
	                .exchange()
	                .expectStatus().isOk()
	                .expectHeader().contentType(MediaType.APPLICATION_JSON_UTF8)
	                .expectBody(Student.class)
	                .consumeWith(response -> {
	                    Student s = response.getResponseBody();
	                    Assertions.assertThat(s.getFullname()).isNotEmpty();
	                    Assertions.assertThat(s.getFullname().length()>0).isTrue();

	                });
	}

	@Test
	public void testFindbyDocument() {
		
		 final Student stu = service.findByDocument("222222").block();
        client.get()
                .uri("/API/Student/document/{number}", Collections.singletonMap("number", stu.getDocument()))
                .accept(MediaType.APPLICATION_JSON_UTF8)
                .exchange()
                .expectStatus().isOk()
                .expectHeader().contentType(MediaType.APPLICATION_JSON_UTF8)
                .expectBody(Student.class)
                .consumeWith(response -> {
                    Student s = response.getResponseBody();
                    Assertions.assertThat(s.getDocument()).isNotEmpty();
                    Assertions.assertThat(s.getDocument().length()>0).isTrue();
                    System.out.println(s.getFullname());

                });
	
	}

	
	
	@Test
	public void testCreateStudent() {
		LocalDate date = LocalDate.parse("1987-05-02");
		Student stu = new Student("5","Michael","M",date,"dni","123456");

        client.post().uri("/API/Student/create")
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .accept(MediaType.APPLICATION_JSON_UTF8)
                .body(Mono.just(stu), Student.class)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON_UTF8)
                .expectBody()
        		.jsonPath("$.id").isNotEmpty()
        		.jsonPath("$.fullname").isEqualTo("Michael");
        		System.out.println(stu.getFullname());
        		
        }

	@Test
	public void testUpdateStudent() {
		Student student = service.findByFullname("Michael").block();

		LocalDate date = LocalDate.parse("1987-05-02");
        Student stuedit = new Student("5", "Jackson","m",date,"dni","556688");

        client.put().uri("/API/Student/update/{id}", Collections.singletonMap("id", student.getId()))
                .contentType(MediaType.APPLICATION_JSON_UTF8)
                .accept(MediaType.APPLICATION_JSON_UTF8)
                .body(Mono.just(stuedit),Student.class)
                .exchange()
                .expectStatus().isCreated()
                .expectHeader().contentType(MediaType.APPLICATION_JSON_UTF8)
                .expectBody()
                .jsonPath("$.id").isNotEmpty()
                .jsonPath("$.fullname").isEqualTo("Jackson")
                ;}

	@Test
	public void testDeleteStudents() 
	{
		 final Student stu = service.findByFullname("Jackson").block();
	        client.delete().uri("/API/Student" + "/delete/{id}", Collections.singletonMap("id", stu.getId())).exchange()
	                .expectStatus().isNoContent()
	                .expectBody()
	                .isEmpty();}

}
